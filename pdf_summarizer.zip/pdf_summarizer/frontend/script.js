document.getElementById("uploadForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const uploadResp = await fetch("/upload", { method: "POST", body: formData });
    const uploadData = await uploadResp.json();
    const summarizeResp = await fetch("/summarize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ doc_id: uploadData.doc_id, level: formData.get("level") })
    });
    const sumData = await summarizeResp.json();
    document.getElementById("result").innerHTML = `
        <p>Summary ready!</p>
        <a href="${sumData.txt}" download>Download TXT</a> |
        <a href="${sumData.pdf}" download>Download PDF</a>
    `;
});
