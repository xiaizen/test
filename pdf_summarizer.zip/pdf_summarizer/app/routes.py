import uuid
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from pydantic import BaseModel
from app.utils import save_uploaded_file, download_file, extract_text_from_pdf, chunk_text
from app.embeddings import init_embedding_model, add_chunks, chunk_meta
from app.summarizer import summarize_text
from app.storage import DOCS_DIR, save_summary_txt, save_summary_pdf, append_training_pair

router = APIRouter()

class UploadResponse(BaseModel):
    doc_id: str
    filename: str
    text_length: int

@router.post("/upload", response_model=UploadResponse)
async def upload(file: UploadFile = File(None), url: str = Form(None)):
    if file is None and not url:
        raise HTTPException(status_code=400, detail="Provide a file or a URL")
    doc_id = str(uuid.uuid4())
    if file:
        filename = file.filename
        dest = DOCS_DIR / f"{doc_id}_{filename}"
        save_uploaded_file(file, dest)
    else:
        filename = url.split("/")[-1] or f"{doc_id}.pdf"
        dest = DOCS_DIR / f"{doc_id}_{filename}"
        download_file(url, dest)
    raw_text = extract_text_from_pdf(dest)
    if not raw_text.strip():
        raise HTTPException(status_code=400, detail="No text extracted from PDF")
    chunks = chunk_text(raw_text)
    init_embedding_model()
    add_chunks(doc_id, chunks)
    (DOCS_DIR / f"{doc_id}.txt").write_text(raw_text, encoding="utf-8")
    return UploadResponse(doc_id=doc_id, filename=filename, text_length=len(raw_text))

class SummarizeRequest(BaseModel):
    doc_id: str
    level: str

@router.post("/summarize")
async def summarize(req: SummarizeRequest):
    chunks_for_doc = [m for m in chunk_meta if m["doc_id"] == req.doc_id]
    if not chunks_for_doc:
        raise HTTPException(status_code=404, detail="Document not found")
    doc_text = "\n\n".join([c["text"] for c in chunks_for_doc])
    final = summarize_text(doc_text, req.level)
    txt_path = save_summary_txt(req.doc_id, req.level, final)
    pdf_path = save_summary_pdf(req.doc_id, req.level, final)
    append_training_pair(doc_text, final)
    return {"doc_id": req.doc_id, "txt": str(txt_path), "pdf": str(pdf_path)}
