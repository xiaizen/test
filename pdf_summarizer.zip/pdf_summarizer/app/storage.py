import os
import json
from pathlib import Path
from fpdf import FPDF

DATA_DIR = Path("data")
DOCS_DIR = DATA_DIR / "docs"
CHUNKS_DIR = DATA_DIR / "chunks"
SUMMARIES_DIR = DATA_DIR / "summaries"
TRAINING_PAIRS_FILE = DATA_DIR / "training_pairs.jsonl"

for d in [DOCS_DIR, CHUNKS_DIR, SUMMARIES_DIR]:
    os.makedirs(d, exist_ok=True)

def save_summary_txt(doc_id: str, level: str, text: str):
    p = SUMMARIES_DIR / f"{doc_id}_{level}.txt"
    p.write_text(text, encoding="utf-8")
    return p

def save_summary_pdf(doc_id: str, level: str, text: str):
    p = SUMMARIES_DIR / f"{doc_id}_{level}.pdf"
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    for line in text.split("\n"):
        for chunk in [line[i:i+90] for i in range(0, len(line), 90)]:
            pdf.cell(0, 6, txt=chunk, ln=1)
    pdf.output(str(p))
    return p

def append_training_pair(doc_text: str, summary_text: str):
    TRAINING_PAIRS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(TRAINING_PAIRS_FILE, "a", encoding="utf-8") as f:
        obj = {"text": doc_text, "summary": summary_text}
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")
