import json
import numpy as np
import faiss
from pathlib import Path
from sentence_transformers import SentenceTransformer

CHUNKS_DIR = Path("data/chunks")
EMBED_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
EMBED_DIM = 384

embed_model = None
embed_index = None
chunk_meta = []

def init_embedding_model():
    global embed_model, embed_index, chunk_meta
    if embed_model is None:
        embed_model = SentenceTransformer(EMBED_MODEL_NAME)
        embed_index = faiss.IndexFlatL2(EMBED_DIM)
        if (CHUNKS_DIR / "_meta.json").exists():
            chunk_meta = json.loads((CHUNKS_DIR / "_meta.json").read_text(encoding="utf-8"))
            if (CHUNKS_DIR / "vectors.npy").exists():
                vecs = np.load(str(CHUNKS_DIR / "vectors.npy"))
                embed_index.add(vecs)
        else:
            chunk_meta = []

def add_chunks(doc_id, chunks):
    vectors = embed_model.encode(chunks, show_progress_bar=False, convert_to_numpy=True)
    embed_index.add(vectors)
    vec_path = CHUNKS_DIR / "vectors.npy"
    if vec_path.exists():
        old = np.load(str(vec_path))
        np.save(str(vec_path), np.vstack([old, vectors]))
    else:
        np.save(str(vec_path), vectors)
    base_index = len(chunk_meta)
    for i, chunk in enumerate(chunks):
        chunk_meta.append({
            "doc_id": doc_id,
            "chunk_id": f"{doc_id}_{i}",
            "text": chunk,
            "global_index": base_index + i,
        })
    (CHUNKS_DIR / "_meta.json").write_text(json.dumps(chunk_meta, ensure_ascii=False), encoding="utf-8")
