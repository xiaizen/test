from transformers import AutoTokenizer, AutoModelForSeq2SeqLM, pipeline

SUMMARIZER_MODEL_NAME = "sshleifer/distilbart-cnn-12-6"
summarizer = None
summarizer_tokenizer = None

def init_summarizer():
    global summarizer, summarizer_tokenizer
    if summarizer is None:
        summarizer_tokenizer = AutoTokenizer.from_pretrained(SUMMARIZER_MODEL_NAME)
        summarizer = AutoModelForSeq2SeqLM.from_pretrained(SUMMARIZER_MODEL_NAME)

def summarize_text(text, level):
    init_summarizer()
    if level == "short":
        max_length, min_length = 60, 20
    elif level == "medium":
        max_length, min_length = 150, 60
    else:
        max_length, min_length = 400, 150
    summarizer_pipeline = pipeline("summarization", model=summarizer, tokenizer=summarizer_tokenizer)
    return summarizer_pipeline(text, max_length=max_length, min_length=min_length, do_sample=False)[0]["summary_text"]
