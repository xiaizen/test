import os
import shutil
import requests
from pathlib import Path
from PyPDF2 import PdfReader

def save_uploaded_file(upload_file, dest: Path):
    with open(dest, "wb") as f:
        shutil.copyfileobj(upload_file.file, f)
    return dest

def download_file(url: str, dest: Path):
    r = requests.get(url, stream=True, timeout=30)
    r.raise_for_status()
    with open(dest, "wb") as f:
        for chunk in r.iter_content(chunk_size=8192):
            if chunk:
                f.write(chunk)
    return dest

def extract_text_from_pdf(path: Path) -> str:
    reader = PdfReader(str(path))
    text_parts = []
    for page in reader.pages:
        try:
            page_text = page.extract_text() or ""
        except Exception:
            page_text = ""
        text_parts.append(page_text)
    return "\n".join(text_parts)

def chunk_text(text: str, chunk_size=800, overlap=200):
    text = text.replace('\r', ' ')
    chunks = []
    start = 0
    length = len(text)
    while start < length:
        end = min(start + chunk_size, length)
        chunk = text[start:end]
        chunks.append(chunk.strip())
        start += chunk_size - overlap
    return [c for c in chunks if c]
