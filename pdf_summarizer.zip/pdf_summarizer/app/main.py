from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from app import routes

app = FastAPI(title="PDF Summarizer")
app.include_router(routes.router)
app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")
